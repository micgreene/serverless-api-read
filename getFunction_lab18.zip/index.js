'use strict';

//3rd party dependencies
const dynamoose = require('dynamoose');

//internal modules
const peopleModel = require('./schema.js');


// All Serverless functions (AWS and Azure) are "async" ...
exports.handler = async (event) => {
  console.log('WORKING');
  try {    
    // event.pathParameters should contain our id
    const id = event.queryStringParameters && event.queryStringParameters.id;

    let data;

    if(id) {
      const list = await peopleModel.query('id').eq(id).exec();
      data = list[0];
    } else {
      data = await peopleModel.scan().exec();
    }
    return {
      statusCode: 200,
      //body: JSON.stringify(event),
      body: JSON.stringify(data),
    };

  } catch (e) {
    return {
      statusCode: 500,
      response: e.message,
    };
  }
}
