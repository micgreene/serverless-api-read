# serverless-api-read
Codefellows 401 Javascript: Lab 18 - AWS: API, Dynamo and Lambda Overview - Read Function
